package sqlsearch;
//��ȡ����

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;


public class dataReader {


private Connection conn;


//�������ݿ�
public void getConnection(String url)throws ClassNotFoundException, SQLException{
	
		Class.forName("com.mysql.jdbc.Driver");
		conn =(Connection) DriverManager.getConnection(url);		
	    
}

//��ȡ���ݿ��ڵ�����
public ArrayList<ProfessorInfo> read() throws SQLException{

	ArrayList<ProfessorInfo> al=new ArrayList<ProfessorInfo>();
	  //������
    String sql="SELECT * FROM teacher.2014302580253.professor_info";  
    Statement sta=(Statement) conn.createStatement();
    ResultSet res=sta.executeQuery(sql);
    while(res.next()){
    	ProfessorInfo pi=new ProfessorInfo();
    	//��ȡ����
    	String sn=(String) res.getObject("name");
    	String sc=(String) res.getObject("email");
    	String sp=(String) res.getObject("phone");
    	String se=(String) res.getObject("educationBackground");
    	String sr=(String) res.getObject("researchInterests");
    	pi.setName(sn);
    	pi.setEmail(sc);
    	pi.setPhone(sp);
    	pi.setEB(se);
    	pi.setRI(sr);
    	al.add(pi);  	
    }
    return al;
	
}



}

