package sqlsearch;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;



//�������ݽ��йؼ���ƥ��
public class keywordMatcher {
private List<String> key;
public ArrayList<searchResult> reList;
private String[] stopWords;//����
private String[] keyWords;
dataReader dr=new dataReader();



//��ȡ����
public keywordMatcher(){
	this.stopWords=new String[]{"a","an","the","and","but","of"};//���˲���Ҫ����
	key=new ArrayList<String>();
	reList=new ArrayList<searchResult>();
}

public void setK(String text){
	
	 this.keyWords=text.split("\\s+");
	 for(int i=0;i<keyWords.length;i++){
		 Boolean b=true;
		 for(int j=0;j<stopWords.length;j++){
			 if(keyWords[i]==stopWords[i]){
				 b=false;//������ȷ�Ĺؼ���
			 }
			 if(b){
			      key.add(keyWords[i]);
			 }
		 }
	 }
}

//����TFֵ
public void TF(ArrayList<ProfessorInfo> res){
	//ѭ������
	for(ProfessorInfo p:res){
		searchResult sR=new searchResult(p,0);
		reList.add(sR);
	}
	
	for(int i=0;i<reList.size();i++){
		for(int j=0;j<key.size();j++){
		    //��������ƥ��
			String s=key.get(j);
			Pattern pa=Pattern.compile(s,Pattern.CASE_INSENSITIVE);	//���Դ�Сд
			Matcher ma=pa.matcher(reList.get(i).toString());
			//����tfֵ
			int num=0;
			while(ma.find()){
				num++;
			}
			int tf=reList.get(i).getTf()+num;
			reList.get(i).setTf(tf);
		}
	}	
}

//����
public void sort(){
	Sort s=new Sort();
	Collections.sort(reList, s);		
}

}


