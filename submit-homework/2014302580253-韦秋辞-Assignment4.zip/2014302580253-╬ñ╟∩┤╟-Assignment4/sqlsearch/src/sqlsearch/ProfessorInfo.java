package sqlsearch;

public class ProfessorInfo {
private String name;	
private String email;
private String phone;
private String eB;
private String rI;



//��ȡ���ڵ�����
public String getName(){
	return  name;
}
	
public void setName(String name){
	this.name=name;
}

//��ȡEmail��ֵ
public String getEmail(){
	return email;
	
}

public void setEmail(String email){
	this.email=email;
}

//��ȡ�绰
public String getPhoneNum(){
	return phone;	
}

public void setPhone(String phone){
	this.phone=phone;
}

//��ȡ���ڵ�ѧ������
public String getEB(){
	return eB;
}

public void setEB(String eB){
	this.eB=eB;
}
//��ȡ���ڵ��о���Ȥ����
public String getRI(){
	return rI;
}

public void setRI(String rI){
	this.rI=rI;
}


	
public String toString(){
	return "\nname:"+name+"Email and phone:"+email+phone+"\neducationBackground:"+eB+"\nresearchInterests"+rI;
}
}