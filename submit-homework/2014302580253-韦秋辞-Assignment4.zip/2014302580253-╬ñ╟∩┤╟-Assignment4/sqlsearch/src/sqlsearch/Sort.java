package sqlsearch;

import java.util.Comparator;


public class Sort implements Comparator<searchResult>{
	public int compare(searchResult sR1,searchResult sR2){
		if (sR1.getTf()>sR2.getTf()){
			return -1;
		}
		else if(sR2.getTf()>sR1.getTf()){
			return 1;
		}
		else {return 0;}
	}
	
}
